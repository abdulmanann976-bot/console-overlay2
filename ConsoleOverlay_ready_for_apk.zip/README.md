# Console Overlay — Cara Membuat APK

Proyek ini adalah aplikasi Android (Kotlin) yang menampilkan tombol overlay
mengambang ("~") yang bisa ditarik ke mana saja di atas aplikasi lain
(misalnya game Godot), dimaksudkan sebagai pemicu console/debug.

Catatan penting: tombol ini **belum bisa mengetik karakter ke aplikasi lain**
(Android tidak mengizinkan itu tanpa Accessibility Service). Saat ditekan,
ia hanya menampilkan notifikasi Toast. Ini titik awal yang bisa
dikembangkan lebih lanjut.

## Cara paling mudah: build otomatis lewat GitHub Actions

1. Buat repository baru di GitHub (bisa privat), misalnya `console-overlay`.
2. Upload/push semua isi folder ini ke repo tersebut.
   ```
   git init
   git add .
   git commit -m "initial commit"
   git branch -M main
   git remote add origin https://github.com/USERNAME/console-overlay.git
   git push -u origin main
   ```
3. Buka tab **Actions** di repo GitHub Anda. Workflow "Build APK" akan
   otomatis berjalan setiap kali Anda push ke branch `main`.
4. Setelah selesai (biasanya 2-4 menit), klik hasil run yang sukses (centang
   hijau), lalu di bagian **Artifacts** unduh `ConsoleOverlay-debug-apk`.
   Di dalamnya ada file `app-debug.apk` — itu APK Anda.
5. Salin APK ke HP Android Anda dan install (aktifkan "Install dari sumber
   tidak dikenal" jika diminta).

Anda juga bisa memicu build manual kapan saja lewat tab Actions →
"Build APK" → "Run workflow", tanpa harus push commit baru.

## Alternatif: build lokal dengan Android Studio

1. Install Android Studio (sudah termasuk Android SDK).
2. Buka folder proyek ini lewat "Open" di Android Studio.
3. Biarkan Gradle sync selesai (otomatis mengunduh dependency).
4. Klik menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. APK hasil build ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Menjalankan aplikasi di HP

1. Install APK-nya.
2. Buka aplikasi "Console Overlay" — akan diminta izin
   "Display over other apps" / "Tampil di atas aplikasi lain". Aktifkan.
3. Buka kembali aplikasinya (atau tap ulang ikonnya) — tombol overlay "~"
   akan muncul mengambang di layar dan bisa ditarik ke posisi mana pun.
